const table = document.querySelector("table");
let size = null;

function createRow(array, indent = 0, className = false, display = true) {
  const tr = document.createElement("tr");

  // for indentation
  for (let i = 0; i < indent; i++) {
    const td = document.createElement("td");
    td.innerHTML = "";
    tr.appendChild(td);
  }

  for (const val of array) {
    const td = document.createElement("td");
    td.innerHTML = val;
    tr.appendChild(td);
  }
  
  for (let i = indent+array.length; i < size; i++) {
    const td = document.createElement("td");
    td.innerHTML = "";
    tr.appendChild(td);
  }

  if (className) tr.classList.add(className);
  if (!display) tr.style.display = "none";
  return tr;
}

// display off for all sub nodes
function dispalyNone(key) {
  const subNodes = document.querySelectorAll(`tr[class^=${key}]`);
  for (const subNode of subNodes) {
    subNode.style.display = "none";
  }
}

function createOpenableRow(text, key, indent, className = false) {
  const tr = createRow([text], indent, className, indent == 0);
  tr.onclick = () => {
    for (const x of document.querySelectorAll("tr." + key)) {
      if (x.style.display == "none") x.style.display = "";
      else {
        x.style.display = "none";
        return dispalyNone(key);
      }
    }
  };
  return tr;
}

function renderArray(dataArray, indent = 0, className = false, display = true) {
  if (dataArray.length == 0) return console.log("nothing to render");

//   table.appendChild(
//     createRow(Object.keys(dataArray[0]), indent, className, display)
//   );
  for (const entry of dataArray) {
    table.appendChild(
      createRow(Object.values(entry), indent, className, display)
    );
  }
}

function renderObject(dataObject, indent = 0, className = false) {
  for (const key in dataObject) {
    const text = `${key} (${
      Array.isArray(dataObject[key]) ? dataObject[key].length : ">"
    })`;
    const currClassName = className + "-" + key.replaceAll(" ", "_");
    table.appendChild(
      createOpenableRow(text, currClassName, indent, className)
    );
    if (Array.isArray(dataObject[key]))
      renderArray(dataObject[key], indent + 1, currClassName, false);
    else renderObject(dataObject[key], indent + 1, currClassName);
  }
}

function renderJSON(dataInput, n, headers) {
  dataInput = JSON.parse(dataInput);
//   console.log(dataInput)
  size = n;
  
  // remove all table rows
  while (table.firstChild) {
    table.removeChild(table.lastChild);
  }
  // render draggable headers
  const headerRow = document.createElement('tr');
  headers.forEach(headerText => {
      const th = document.createElement('th');
      th.textContent = headerText.trim();
      th.setAttribute('draggable', true);
      th.addEventListener('dragstart', handleDragStart);
      headerRow.appendChild(th);
  });
  table.appendChild(headerRow);

  if (Array.isArray(dataInput)) {
    renderArray(dataInput);
  } else renderObject(dataInput, 0, "tr");
}

/* All
renderJSON(`[
    {
        "index": 1,
        "name": "John Smith",
        "age": 30,
        "gender": "male",
        "working": "no"
    },
    {
        "index": 2,
        "name": "Emily Johnson",
        "age": 25,
        "gender": "female",
        "working": "yes"
    },
    {
        "index": 3,
        "name": "Michael Brown",
        "age": 35,
        "gender": "male",
        "working": "yes"
    },
    {
        "index": 4,
        "name": "Jessica Lee",
        "age": 28,
        "gender": "female",
        "working": "no"
    },
    {
        "index": 5,
        "name": "David Rodriguez",
        "age": 32,
        "gender": "male",
        "working": "yes"
    },
    {
        "index": 6,
        "name": "Samantha Martinez",
        "age": 27,
        "gender": "female",
        "working": "no"
    },
    {
        "index": 7,
        "name": "Christopher Nguyen",
        "age": 29,
        "gender": "male",
        "working": "yes"
    },
    {
        "index": 8,
        "name": "Ashley Taylor",
        "age": 24,
        "gender": "female",
        "working": "yes"
    },
    {
        "index": 9,
        "name": "Daniel Kim",
        "age": 31,
        "gender": "male",
        "working": "no"
    },
    {
        "index": 10,
        "name": "Rachel Hernandez",
        "age": 26,
        "gender": "female",
        "working": "yes"
    },
    {
        "index": 11,
        "name": "Alex Johnson",
        "age": 30,
        "gender": "male",
        "working": "yes"
    },
    {
        "index": 12,
        "name": "Sophia Brown",
        "age": 35,
        "gender": "female",
        "working": "no"
    },
    {
        "index": 13,
        "name": "Ethan Smith",
        "age": 25,
        "gender": "male",
        "working": "yes"
    },
    {
        "index": 14,
        "name": "Olivia Lee",
        "age": 28,
        "gender": "female",
        "working": "no"
    },
    {
        "index": 15,
        "name": "Noah Rodriguez",
        "age": 32,
        "gender": "male",
        "working": "yes"
    }
]
`)
*/

/* One
renderJSON(`{
    "male": [
        {
            "index": 1,
            "name": "John Smith",
            "age": 30,
            "working": "no"
        },
        {
            "index": 3,
            "name": "Michael Brown",
            "age": 35,
            "working": "yes"
        },
        {
            "index": 5,
            "name": "David Rodriguez",
            "age": 32,
            "working": "yes"
        },
        {
            "index": 7,
            "name": "Christopher Nguyen",
            "age": 29,
            "working": "yes"
        },
        {
            "index": 9,
            "name": "Daniel Kim",
            "age": 31,
            "working": "no"
        },
        {
            "index": 11,
            "name": "Alex Johnson",
            "age": 30,
            "working": "yes"
        },
        {
            "index": 13,
            "name": "Ethan Smith",
            "age": 25,
            "working": "yes"
        },
        {
            "index": 15,
            "name": "Noah Rodriguez",
            "age": 32,
            "working": "yes"
        }
    ],
    "female": [
        {
            "index": 2,
            "name": "Emily Johnson",
            "age": 25,
            "working": "yes"
        },
        {
            "index": 4,
            "name": "Jessica Lee",
            "age": 28,
            "working": "no"
        },
        {
            "index": 6,
            "name": "Samantha Martinez",
            "age": 27,
            "working": "no"
        },
        {
            "index": 8,
            "name": "Ashley Taylor",
            "age": 24,
            "working": "yes"
        },
        {
            "index": 10,
            "name": "Rachel Hernandez",
            "age": 26,
            "working": "yes"
        },
        {
            "index": 12,
            "name": "Sophia Brown",
            "age": 35,
            "working": "no"
        },
        {
            "index": 14,
            "name": "Olivia Lee",
            "age": 28,
            "working": "no"
        }
    ]
}
`);
*/

/* Two
renderJSON(`{
    "male": {
        "yes": [
            {
                "index": 3,
                "name": "Michael Brown",
                "age": 35
            },
            {
                "index": 5,
                "name": "David Rodriguez",
                "age": 32
            },
            {
                "index": 7,
                "name": "Christopher Nguyen",
                "age": 29
            },
            {
                "index": 11,
                "name": "Alex Johnson",
                "age": 30
            },
            {
                "index": 13,
                "name": "Ethan Smith",
                "age": 25
            },
            {
                "index": 15,
                "name": "Noah Rodriguez",
                "age": 32
            }
        ],
        "no": [
            {
                "index": 1,
                "name": "John Smith",
                "age": 30
            },
            {
                "index": 9,
                "name": "Daniel Kim",
                "age": 31
            }
        ]
    },
    "female": {
        "yes": [
            {
                "index": 2,
                "name": "Emily Johnson",
                "age": 25
            },
            {
                "index": 8,
                "name": "Ashley Taylor",
                "age": 24
            },
            {
                "index": 10,
                "name": "Rachel Hernandez",
                "age": 26
            }
        ],
        "no": [
            {
                "index": 4,
                "name": "Jessica Lee",
                "age": 28
            },
            {
                "index": 6,
                "name": "Samantha Martinez",
                "age": 27
            },
            {
                "index": 12,
                "name": "Sophia Brown",
                "age": 35
            },
            {
                "index": 14,
                "name": "Olivia Lee",
                "age": 28
            }
        ]
    }
}
`);
*/
