let csvData = []; // Global variable to store CSV data in JSON format
let csvHeaders = [];

function afterCSVLoads(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(event) {
        const csv = event.target.result;
        const lines = csv.split(/\r\n|\n/);
        const headers = lines[0].split(',');
        csvHeaders = headers;

        for (let i = 1; i < lines.length-1; i++) {
            const currentLine = lines[i].split(',');
            const rowData = {};

            for (let j = 0; j < headers.length; j++) {
                rowData[headers[j]] = currentLine[j];
            }

            csvData.push(rowData);
        }
    };

    reader.readAsText(file);
}


function rearrangeColumns(selectedColumns, allColumns) {
    // Filter out selected columns from all columns
    const remainingColumns = allColumns.filter(column => !selectedColumns.includes(column));
    
    // Concatenate selected columns with remaining columns
    const rearrangedColumns = selectedColumns.concat(remainingColumns);

    return rearrangedColumns;
}

function printHeaderContainerContents() {
    const keys = document.getElementById("header-container").textContent.split('❌').slice(0, -1);
    console.log("UPDATE: ", keys);
    try {
        const tableContainer = document.getElementById('table-container');
        if (tableContainer) {
            tableContainer.parentNode.removeChild(tableContainer);
        } else {
            console.log('Element with ID "table-container" not found.');
        }
    } catch (error) {
        console.error('An error occurred while removing the element:', error);
    }
    const copiedCsvData = csvData.map(obj => ({ ...obj }));
    const filtered = subCategorizeJSON(copiedCsvData, keys);
    renderJSON(JSON.stringify(filtered, null, 2), csvHeaders.length, rearrangeColumns(keys, csvHeaders));
}

const observer = new MutationObserver(printHeaderContainerContents);
const config = { childList: true, subtree: true };

observer.observe(document.getElementById("header-container"), config);
