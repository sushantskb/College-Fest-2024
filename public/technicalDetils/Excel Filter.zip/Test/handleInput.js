document.getElementById('csv-file').addEventListener('change', handleFileSelect, false);

function handleFileSelect(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(event) {
        const contents = event.target.result;
        displayCSVContents(contents);
    };

    reader.readAsText(file);
}

function displayCSVContents(csvContent) {
    const lines = csvContent.trim().split('\n');

    // Create array to store CSV headers
    const headers = lines.shift().trim().split(',');

    // Create table
    const table = document.createElement('table');

    // Create table headers
    const headerRow = document.createElement('tr');
    headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText.trim();
        th.setAttribute('draggable', true);
        th.addEventListener('dragstart', handleDragStart);
        headerRow.appendChild(th);
    });
    table.appendChild(headerRow);

    // Create table rows
    lines.forEach(line => {
        const row = document.createElement('tr');
        const cells = line.trim().split(',');
        cells.forEach(cellText => {
            const td = document.createElement('td');
            td.textContent = cellText.trim();
            row.appendChild(td);
        });
        table.appendChild(row);
    });

    // Add table to the container
    document.getElementById('table-container').innerHTML = '';
    document.getElementById('table-container').appendChild(table);
}

function handleDragStart(event) {
    event.dataTransfer.setData('text/plain', event.target.textContent);
}

const csvInput = document.getElementById('csv-input');
csvInput.addEventListener('dragover', handleDragOver);
csvInput.addEventListener('drop', handleDrop);

function handleDragOver(event) {
    event.preventDefault();
}

function handleDrop(event) {
    event.preventDefault();
    const draggedText = event.dataTransfer.getData('text/plain');
    addHeader(draggedText.trim());
}

const headerContainer = document.getElementById('header-container');
const addedHeaders = []; // Array to store already added headers

function addHeader(headerText) {
    if (!addedHeaders.includes(headerText)) { // Check if header is already added
        addedHeaders.push(headerText); // Add header to list of added headers

        const headerBox = document.createElement('div');
        headerBox.classList.add('header-box');

        const headerTextElement = document.createElement('span');
        headerTextElement.textContent = headerText.trim();
        headerTextElement.contentEditable = true; // Make the text editable

        const crossButton = document.createElement('button');
        crossButton.textContent = '❌';
        crossButton.addEventListener('click', () => {
            headerBox.remove();
            const index = addedHeaders.indexOf(headerText);
            if (index !== -1) {
                addedHeaders.splice(index, 1); // Remove header from list of added headers
            }
        });

        headerBox.appendChild(headerTextElement);
        headerBox.appendChild(crossButton);
        headerContainer.appendChild(headerBox);

        headerTextElement.addEventListener('input', () => {
            // Handle input changes here
            console.log(headerTextElement.textContent.trim());
        });
    }
}
const inputContainer = document.getElementById('input-container');
inputContainer.addEventListener('input', handleInputChange);

function handleInputChange(event) {
    const currentValue = event.target.value;
    const lastCommaIndex = currentValue.lastIndexOf(',');
    if (lastCommaIndex !== -1) {
        const lastItem = currentValue.substring(lastCommaIndex + 1).trim();
        if (!lastItem) {
            event.target.value = currentValue.substring(0, lastCommaIndex);
        }
    }
}
