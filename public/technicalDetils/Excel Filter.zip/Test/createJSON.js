function removeKeys(obj, keysToRemove) {
    keysToRemove.forEach(key => {
        delete obj[key];
    });

    Object.values(obj).forEach(value => {
        if (typeof value === 'object') {
            removeKeys(value, keysToRemove);
        }
    });
}

function subCategorizeJSON(data, keys) {
  const categorizedData = {};
  
  data.forEach(entry => {
    let currentLevel = categorizedData;

    keys.forEach((key, index) => {
        const value = entry[key];
        if (index === keys.length - 1) {
            currentLevel[value] = currentLevel[value] || [];
            currentLevel[value].push(entry);
        } else {
            currentLevel[value] = currentLevel[value] || {};
            currentLevel = currentLevel[value];
        }
    });
  });

  removeKeys(categorizedData, keys);
  return categorizedData;
}

// // Using Node.js fs module
// const fs = require('fs');

// fs.readFile('../Examples/all.json', 'utf8', (err, json) => {
//   if (err) {
//     console.error('Error:', err);
//     return;
//   }

//   try {
//     const data = JSON.parse(json);
//     // Use the loaded JSON data
//     const keys = ["gender", "working", "age"]; // Customize the keys here
//     const result = subCategorizeJSON(data, keys);
//     // console.log(result);
//     console.log(JSON.stringify(result, null, 2));

//   } catch (error) {
//     console.error('Error parsing JSON:', error);
//   }
// });

